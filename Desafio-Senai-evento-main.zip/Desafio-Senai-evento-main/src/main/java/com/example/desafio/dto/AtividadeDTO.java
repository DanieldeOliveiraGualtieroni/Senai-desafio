package com.example.desafio.dto;

public record AtividadeDTO(Integer id, String nome, String descricao, Double preco) {

}
