package com.example.desafio.dto;

public record CategoriaDTO(Integer id, String descricao) {

}
