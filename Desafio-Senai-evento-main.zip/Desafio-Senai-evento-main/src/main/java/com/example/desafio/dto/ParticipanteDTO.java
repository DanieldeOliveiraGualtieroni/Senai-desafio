package com.example.desafio.dto;

public record ParticipanteDTO(Integer id, String nome, String email) {

}
