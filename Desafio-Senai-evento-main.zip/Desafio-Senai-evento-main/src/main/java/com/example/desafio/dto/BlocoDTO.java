package com.example.desafio.dto;

import java.time.Instant;

public record BlocoDTO(Integer id, Instant inicio,Instant fim) {

}
