package com.example.desafio.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.desafio.models.Bloco;

public interface BlocoRepository extends JpaRepository<Bloco, Integer>{

}
